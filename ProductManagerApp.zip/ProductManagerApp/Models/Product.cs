﻿namespace ProductManagerApp.Models
{
    public class Product
    {
        internal object Title;

        public int Id { get; set; }
        public string? Name { get; set; }
        public int Quantity { get; set; }
    }
}
